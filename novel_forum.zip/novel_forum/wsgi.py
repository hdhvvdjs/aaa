"""
墨香阁 - WSGI入口文件
用于生产环境部署
"""

from app import app, db
from models import User, Category, Post, Comment

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=8080)
