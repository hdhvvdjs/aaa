/**
 * 墨香阁 - 网文小说论坛
 * 前端交互脚本
 */

document.addEventListener('DOMContentLoaded', function() {
    // 初始化所有功能
    initFlashMessages();
    initConfirmDelete();
    initSearchCollapse();
    initTabs();
    initMobileMenu();
});

/**
 * 消息提示自动消失
 */
function initFlashMessages() {
    const messages = document.querySelectorAll('.flash');
    messages.forEach(function(message) {
        setTimeout(function() {
            message.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(function() {
                message.remove();
            }, 300);
        }, 5000);
    });
}

// 添加滑出动画
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);

/**
 * 删除确认
 */
function initConfirmDelete() {
    document.querySelectorAll('.btn-delete, [data-confirm]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            const message = btn.dataset.confirm || '确定要删除吗？此操作无法撤销。';
            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        });
    });

    // 表单删除确认
    document.querySelectorAll('form[data-confirm]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const message = form.dataset.confirm || '确定要执行此操作吗？';
            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        });
    });
}

/**
 * 搜索折叠（移动端）
 */
function initSearchCollapse() {
    const searchToggle = document.querySelector('.search-toggle');
    const searchForm = document.querySelector('.search-form');

    if (searchToggle && searchForm) {
        searchToggle.addEventListener('click', function() {
            searchForm.classList.toggle('active');
        });
    }
}

/**
 * Tabs切换
 */
function initTabs() {
    document.querySelectorAll('.tabs').forEach(function(tabsContainer) {
        const tabs = tabsContainer.querySelectorAll('.tab-item');
        tabs.forEach(function(tab) {
            tab.addEventListener('click', function() {
                // 移除所有active
                tabs.forEach(function(t) { t.classList.remove('active'); });
                // 添加active到当前
                tab.classList.add('active');

                // 触发自定义事件
                const event = new CustomEvent('tabChange', {
                    detail: { tab: tab.dataset.tab }
                });
                tabsContainer.dispatchEvent(event);
            });
        });
    });
}

/**
 * 移动端菜单
 */
function initMobileMenu() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navbarMenu = document.querySelector('.navbar-menu');

    if (menuToggle && navbarMenu) {
        menuToggle.addEventListener('click', function() {
            navbarMenu.classList.toggle('active');
            menuToggle.classList.toggle('active');
        });

        // 点击菜单外关闭
        document.addEventListener('click', function(e) {
            if (!navbarMenu.contains(e.target) && !menuToggle.contains(e.target)) {
                navbarMenu.classList.remove('active');
                menuToggle.classList.remove('active');
            }
        });
    }
}

/**
 * 格式化时间戳
 */
function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (seconds < 60) return '刚刚';
    if (minutes < 60) return minutes + '分钟前';
    if (hours < 24) return hours + '小时前';
    if (days < 30) return days + '天前';

    return date.toLocaleDateString('zh-CN');
}

/**
 * 文本字数统计
 */
function countCharacters(textarea) {
    const count = textarea.value.length;
    const counter = document.querySelector(`#${textarea.id}-counter`);
    if (counter) {
        counter.textContent = `${count} / ${textarea.maxLength || '∞'}`;
    }
    return count;
}

/**
 * 表单验证
 */
function validateForm(form) {
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');

    requiredFields.forEach(function(field) {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });

    return isValid;
}

/**
 * 平滑滚动到元素
 */
function scrollToElement(element, offset = 0) {
    const top = element.getBoundingClientRect().top + window.pageYOffset - offset;
    window.scrollTo({
        top: top,
        behavior: 'smooth'
    });
}

/**
 * 防抖函数
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * 节流函数
 */
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * 复制文本到剪贴板
 */
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function() {
            showNotification('已复制到剪贴板', 'success');
        }, function() {
            fallbackCopyToClipboard(text);
        });
    } else {
        fallbackCopyToClipboard(text);
    }
}

function fallbackCopyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
        document.execCommand('copy');
        showNotification('已复制到剪贴板', 'success');
    } catch (err) {
        showNotification('复制失败', 'error');
    }
    document.body.removeChild(textarea);
}

/**
 * 显示通知
 */
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `flash flash-${type}`;
    notification.textContent = message;

    let container = document.querySelector('.flash-messages');
    if (!container) {
        container = document.createElement('div');
        container.className = 'flash-messages';
        document.body.appendChild(container);
    }

    container.appendChild(notification);

    setTimeout(function() {
        notification.style.animation = 'slideOut 0.3s ease forwards';
        setTimeout(function() {
            notification.remove();
        }, 300);
    }, 3000);
}

/**
 * 加载更多内容（无限滚动辅助）
 */
const loadMoreObserver = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
        if (entry.isIntersecting) {
            const trigger = entry.target;
            const callback = trigger.dataset.loadMore;
            if (callback && typeof window[callback] === 'function') {
                window[callback]();
            }
        }
    });
}, {
    rootMargin: '100px'
});

function observeLoadMore(element) {
    if (element) {
        loadMoreObserver.observe(element);
    }
}

/**
 * 图片懒加载
 */
function initLazyLoad() {
    const lazyImages = document.querySelectorAll('img[data-src]');

    const imageObserver = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                imageObserver.unobserve(img);
            }
        });
    });

    lazyImages.forEach(function(img) {
        imageObserver.observe(img);
    });
}

// 初始化图片懒加载
initLazyLoad();

/**
 * 评论区交互
 */
function initCommentSection() {
    const commentForm = document.querySelector('.comment-form form');
    const commentList = document.querySelector('.comment-list');

    if (commentForm) {
        commentForm.addEventListener('submit', function(e) {
            if (!validateForm(commentForm)) {
                e.preventDefault();
                return false;
            }
        });

        // 字数统计
        const textarea = commentForm.querySelector('textarea');
        if (textarea) {
            textarea.addEventListener('input', function() {
                countCharacters(textarea);
            });
        }
    }

    // 评论回复功能（预留）
    document.querySelectorAll('.comment-reply-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const commentId = btn.dataset.commentId;
            const replyForm = document.querySelector(`#reply-form-${commentId}`);
            if (replyForm) {
                replyForm.classList.toggle('active');
                scrollToElement(replyForm, 100);
            }
        });
    });
}

initCommentSection();

/**
 * 管理员操作确认
 */
function initAdminActions() {
    document.querySelectorAll('[data-action]').forEach(function(element) {
        element.addEventListener('click', function(e) {
            const action = this.dataset.action;
            const item = this.dataset.item;
            const actionText = {
                'disable': '禁用',
                'enable': '启用',
                'delete': '删除',
                'promote': '设为管理员',
                'demote': '取消管理员'
            };

            if (actionText[action]) {
                const message = `确定要${actionText[action]} ${item} 吗？`;
                if (!confirm(message)) {
                    e.preventDefault();
                    return false;
                }
            }
        });
    });
}

initAdminActions();

/**
 * 表单自动保存草稿
 */
function initAutoSave() {
    const forms = document.querySelectorAll('[data-autosave]');

    forms.forEach(function(form) {
        const key = form.dataset.autosave;
        const inputs = form.querySelectorAll('input, textarea, select');

        // 加载草稿
        const saved = localStorage.getItem(key);
        if (saved) {
            try {
                const data = JSON.parse(saved);
                inputs.forEach(function(input) {
                    if (data[input.name]) {
                        input.value = data[input.name];
                    }
                });
            } catch (e) {
                console.error('Failed to load autosave:', e);
            }
        }

        // 保存草稿
        const saveDraft = debounce(function() {
            const data = {};
            inputs.forEach(function(input) {
                if (input.name) {
                    data[input.name] = input.value;
                }
            });
            localStorage.setItem(key, JSON.stringify(data));
        }, 1000);

        inputs.forEach(function(input) {
            input.addEventListener('input', saveDraft);
        });

        // 清除草稿
        form.addEventListener('submit', function() {
            localStorage.removeItem(key);
        });
    });
}

initAutoSave();

/**
 * 导出所有函数到全局
 */
window.MXG = {
    showNotification,
    copyToClipboard,
    validateForm,
    scrollToElement,
    debounce,
    throttle,
    initLazyLoad,
    initCommentSection,
    initAdminActions,
    initAutoSave,
    observeLoadMore
};
