"""
翰林阁 - 网文小说论坛
Flask主应用 - 云端部署版本
"""

import os
from flask import Flask, render_template, redirect, url_for, request, flash, abort
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError
from datetime import datetime
from models import db, User, Category, Post, Comment

# 创建Flask应用
app = Flask(__name__)

# 配置管理
class Config:
    """基础配置"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'hanlin-ge-secret-key-2024-dev'

    # 数据库配置 - 支持PostgreSQL和SQLite
    # PostgreSQL用于云端部署
    DATABASE_URL = os.environ.get('DATABASE_URL')

    if DATABASE_URL:
        # PostgreSQL (Railway, Render, Heroku等云平台)
        if DATABASE_URL.startswith('postgres://'):
            DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql://', 1)
        app.config['SQLALCHEMY_DATABASE_URI'] = DATABASE_URL
    else:
        # SQLite (本地开发)
        basedir = os.path.abspath(os.path.dirname(__file__))
        app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(basedir, "novel_forum.db")}'

    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # 分页配置
    POSTS_PER_PAGE = int(os.environ.get('POSTS_PER_PAGE', 15))
    COMMENTS_PER_PAGE = int(os.environ.get('COMMENTS_PER_PAGE', 10))


# 创建应用
app = Flask(__name__)
app.config.from_object(Config)

# 初始化扩展
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = '请先登录后再进行操作'

@login_manager.user_loader
def load_user(user_id):
    """加载用户（Flask-Login必需）"""
    return User.query.get(int(user_id))


# ==================== 表单定义 ====================

class RegistrationForm(FlaskForm):
    """注册表单"""
    username = StringField('用户名', validators=[
        DataRequired(message='用户名不能为空'),
        Length(min=3, max=20, message='用户名长度需在3-20个字符之间')
    ])
    email = StringField('邮箱', validators=[
        DataRequired(message='邮箱不能为空'),
        Email(message='请输入有效的邮箱地址')
    ])
    password = PasswordField('密码', validators=[
        DataRequired(message='密码不能为空'),
        Length(min=6, message='密码长度至少6个字符')
    ])
    confirm_password = PasswordField('确认密码', validators=[
        DataRequired(message='请确认密码'),
        EqualTo('password', message='两次输入的密码不一致')
    ])

    def validate_username(self, field):
        if User.query.filter_by(username=field.data).first():
            raise ValidationError('该用户名已被注册')

    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError('该邮箱已被注册')


class LoginForm(FlaskForm):
    """登录表单"""
    username = StringField('用户名', validators=[DataRequired(message='用户名不能为空')])
    password = PasswordField('密码', validators=[DataRequired(message='密码不能为空')])


class PostForm(FlaskForm):
    """发帖表单"""
    title = StringField('标题', validators=[
        DataRequired(message='标题不能为空'),
        Length(max=200, message='标题不能超过200个字符')
    ])
    category_id = SelectField('分类', coerce=int, validators=[DataRequired(message='请选择分类')])
    content = TextAreaField('内容', validators=[
        DataRequired(message='内容不能为空'),
        Length(min=10, message='内容至少10个字符')
    ])


class CommentForm(FlaskForm):
    """评论表单"""
    content = TextAreaField('评论', validators=[
        DataRequired(message='评论内容不能为空'),
        Length(min=2, max=500, message='评论长度需在2-500个字符之间')
    ])


class ProfileForm(FlaskForm):
    """个人资料表单"""
    avatar = StringField('头像URL')
    bio = TextAreaField('个人简介', validators=[Length(max=500, message='简介不能超过500个字符')])


class AdminUserForm(FlaskForm):
    """管理员用户表单"""
    is_active = SelectField('状态', choices=[('1', '激活'), ('0', '禁用')])
    is_admin = SelectField('权限', choices=[('0', '普通用户'), ('1', '管理员')])


# ==================== 过滤器 ====================

@app.template_filter('time_ago')
def time_ago(dt):
    """时间格式化过滤器"""
    if not dt:
        return ''
    now = datetime.utcnow()
    diff = now - dt

    seconds = diff.total_seconds()
    if seconds < 60:
        return '刚刚'
    minutes = int(seconds / 60)
    if minutes < 60:
        return f'{minutes}分钟前'
    hours = int(minutes / 60)
    if hours < 24:
        return f'{hours}小时前'
    days = int(hours / 24)
    if days < 30:
        return f'{days}天前'
    months = int(days / 30)
    if months < 12:
        return f'{months}个月前'
    years = int(months / 12)
    return f'{years}年前'


# ==================== 路由 ====================

# 公开路由
@app.route('/')
def index():
    """首页"""
    page = request.args.get('page', 1, type=int)
    category_id = request.args.get('category', type=int)
    search_query = request.args.get('q', '')

    # 获取分类列表
    categories = Category.query.all()

    # 构建查询
    query = Post.query

    if category_id:
        query = query.filter_by(category_id=category_id)

    if search_query:
        query = query.filter(
            db.or_(
                Post.title.contains(search_query),
                Post.content.contains(search_query)
            )
        )

    # 分页获取帖子
    pagination = query.order_by(Post.created_at.desc()).paginate(
        page=page, per_page=app.config['POSTS_PER_PAGE'], error_out=False
    )

    # 获取热门帖子
    hot_posts = Post.query.order_by(Post.view_count.desc()).limit(5).all()

    return render_template('index.html',
                           posts=pagination.items,
                           pagination=pagination,
                           categories=categories,
                           hot_posts=hot_posts,
                           current_category=category_id,
                           search_query=search_query)


@app.route('/post/<int:post_id>')
def post_detail(post_id):
    """帖子详情页"""
    post = Post.query.get_or_404(post_id)
    post.view_count += 1
    db.session.commit()

    # 获取评论
    comments = Comment.query.filter_by(post_id=post_id).order_by(Comment.created_at.desc()).all()

    comment_form = CommentForm()

    return render_template('post_detail.html',
                           post=post,
                           comments=comments,
                           comment_form=comment_form)


@app.route('/category/<int:category_id>')
def category_posts(category_id):
    """分类帖子列表"""
    category = Category.query.get_or_404(category_id)
    page = request.args.get('page', 1, type=int)
    categories = Category.query.all()

    pagination = Post.query.filter_by(category_id=category_id)\
        .order_by(Post.created_at.desc())\
        .paginate(page=page, per_page=app.config['POSTS_PER_PAGE'], error_out=False)

    hot_posts = Post.query.order_by(Post.view_count.desc()).limit(5).all()

    return render_template('index.html',
                           posts=pagination.items,
                           pagination=pagination,
                           categories=categories,
                           hot_posts=hot_posts,
                           current_category=category_id)


# 用户认证路由
@app.route('/register', methods=['GET', 'POST'])
def register():
    """用户注册"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('注册成功！请登录', 'success')
        return redirect(url_for('login'))

    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    """用户登录"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            if not user.is_active:
                flash('该账户已被禁用', 'danger')
                return render_template('login.html', form=form)
            login_user(user)
            flash(f'欢迎回来，{user.username}！', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('用户名或密码错误', 'danger')

    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def logout():
    """用户登出"""
    logout_user()
    flash('已退出登录', 'info')
    return redirect(url_for('index'))


# 用户功能路由
@app.route('/user/<username>')
def user_profile(username):
    """用户主页"""
    user = User.query.filter_by(username=username).first_or_404()

    page = request.args.get('page', 1, type=int)
    tab = request.args.get('tab', 'posts')

    if tab == 'posts':
        pagination = user.posts.order_by(Post.created_at.desc())\
            .paginate(page=page, per_page=app.config['COMMENTS_PER_PAGE'], error_out=False)
        items = pagination.items
    else:
        pagination = user.comments.order_by(Comment.created_at.desc())\
            .paginate(page=page, per_page=app.config['COMMENTS_PER_PAGE'], error_out=False)
        items = pagination.items

    return render_template('user_profile.html',
                           profile_user=user,
                           items=items,
                           pagination=pagination,
                           current_tab=tab)


@app.route('/edit-profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    """编辑个人资料"""
    form = ProfileForm()

    if form.validate_on_submit():
        current_user.avatar = form.avatar.data or current_user.avatar
        current_user.bio = form.bio.data
        db.session.commit()
        flash('个人资料已更新', 'success')
        return redirect(url_for('user_profile', username=current_user.username))

    form.avatar.data = current_user.avatar
    form.bio.data = current_user.bio

    return render_template('edit_profile.html', form=form)


@app.route('/post/create', methods=['GET', 'POST'])
@login_required
def create_post():
    """发布新帖"""
    form = PostForm()
    form.category_id.choices = [(c.id, c.name) for c in Category.query.all()]

    if form.validate_on_submit():
        post = Post(
            title=form.title.data,
            content=form.content.data,
            category_id=form.category_id.data,
            author_id=current_user.id
        )
        db.session.add(post)
        db.session.commit()
        flash('帖子发布成功！', 'success')
        return redirect(url_for('post_detail', post_id=post.id))

    categories = Category.query.all()
    return render_template('create_post.html', form=form, categories=categories)


@app.route('/post/<int:post_id>/comment', methods=['POST'])
@login_required
def add_comment(post_id):
    """添加评论"""
    post = Post.query.get_or_404(post_id)
    form = CommentForm()

    if form.validate_on_submit():
        comment = Comment(
            content=form.content.data,
            post_id=post.id,
            author_id=current_user.id
        )
        db.session.add(comment)
        db.session.commit()
        flash('评论发布成功！', 'success')

    return redirect(url_for('post_detail', post_id=post_id))


@app.route('/post/<int:post_id>/delete', methods=['POST'])
@login_required
def delete_post(post_id):
    """删除帖子"""
    post = Post.query.get_or_404(post_id)

    if current_user != post.author and not current_user.is_admin:
        abort(403)

    db.session.delete(post)
    db.session.commit()
    flash('帖子已删除', 'success')

    if current_user.is_admin:
        return redirect(url_for('admin_posts'))
    return redirect(url_for('index'))


@app.route('/comment/<int:comment_id>/delete', methods=['POST'])
@login_required
def delete_comment(comment_id):
    """删除评论"""
    comment = Comment.query.get_or_404(comment_id)

    if current_user != comment.author and not current_user.is_admin:
        abort(403)

    post_id = comment.post_id
    db.session.delete(comment)
    db.session.commit()
    flash('评论已删除', 'success')

    if current_user.is_admin:
        return redirect(url_for('admin_comments'))
    return redirect(url_for('post_detail', post_id=post_id))


# 管理员路由
@app.route('/admin')
@login_required
def admin_dashboard():
    """管理员仪表盘"""
    if not current_user.is_admin:
        abort(403)

    stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter_by(is_active=True).count(),
        'total_posts': Post.query.count(),
        'total_comments': Comment.query.count(),
        'total_categories': Category.query.count()
    }

    recent_posts = Post.query.order_by(Post.created_at.desc()).limit(5).all()
    recent_comments = Comment.query.order_by(Comment.created_at.desc()).limit(5).all()

    return render_template('admin_dashboard.html',
                           stats=stats,
                           recent_posts=recent_posts,
                           recent_comments=recent_comments)


@app.route('/admin/users')
@login_required
def admin_users():
    """用户管理"""
    if not current_user.is_admin:
        abort(403)

    page = request.args.get('page', 1, type=int)
    pagination = User.query.order_by(User.created_at.desc())\
        .paginate(page=page, per_page=20, error_out=False)

    return render_template('admin_users.html', pagination=pagination)


@app.route('/admin/users/<int:user_id>/toggle-active', methods=['POST'])
@login_required
def toggle_user_active(user_id):
    """切换用户激活状态"""
    if not current_user.is_admin:
        abort(403)

    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        flash('不能禁用自己的账户', 'danger')
        return redirect(url_for('admin_users'))

    user.is_active = not user.is_active
    db.session.commit()
    status = '激活' if user.is_active else '禁用'
    flash(f'用户 {user.username} 已{status}', 'success')

    return redirect(url_for('admin_users'))


@app.route('/admin/users/<int:user_id>/toggle-admin', methods=['POST'])
@login_required
def toggle_user_admin(user_id):
    """切换用户管理员权限"""
    if not current_user.is_admin:
        abort(403)

    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        flash('不能修改自己的管理员权限', 'danger')
        return redirect(url_for('admin_users'))

    user.is_admin = not user.is_admin
    db.session.commit()
    status = '设为' if user.is_admin else '取消'
    flash(f'用户 {user.username} 已{status}管理员', 'success')

    return redirect(url_for('admin_users'))


@app.route('/admin/users/<int:user_id>/delete', methods=['POST'])
@login_required
def admin_delete_user(user_id):
    """删除用户"""
    if not current_user.is_admin:
        abort(403)

    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        flash('不能删除自己的账户', 'danger')
        return redirect(url_for('admin_users'))

    db.session.delete(user)
    db.session.commit()
    flash(f'用户 {user.username} 已删除', 'success')

    return redirect(url_for('admin_users'))


@app.route('/admin/posts')
@login_required
def admin_posts():
    """帖子管理"""
    if not current_user.is_admin:
        abort(403)

    page = request.args.get('page', 1, type=int)
    pagination = Post.query.order_by(Post.created_at.desc())\
        .paginate(page=page, per_page=20, error_out=False)

    return render_template('admin_posts.html', pagination=pagination)


@app.route('/admin/comments')
@login_required
def admin_comments():
    """评论管理"""
    if not current_user.is_admin:
        abort(403)

    page = request.args.get('page', 1, type=int)
    pagination = Comment.query.order_by(Comment.created_at.desc())\
        .paginate(page=page, per_page=30, error_out=False)

    return render_template('admin_comments.html', pagination=pagination)


@app.route('/admin/categories')
@login_required
def admin_categories():
    """分类管理"""
    if not current_user.is_admin:
        abort(403)

    categories = Category.query.all()
    return render_template('admin_categories.html', categories=categories)


# 错误处理
@app.errorhandler(403)
def forbidden(e):
    return render_template('error.html', error_code=403, message='权限不足'), 403


@app.errorhandler(404)
def not_found(e):
    return render_template('error.html', error_code=404, message='页面不存在'), 404


@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', error_code=500, message='服务器错误'), 500


# 创建数据库表
def init_db():
    """初始化数据库"""
    with app.app_context():
        db.create_all()
        from models import init_default_data
        init_default_data()


if __name__ == '__main__':
    # 本地开发模式
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)
