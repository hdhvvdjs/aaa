---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304502201a5f99657d61af9ff043680037d69d4ff65563b202e704b52a72282e21e4ce4902210085c00596d5041b7449a22f0eb57e2618b42ebf002c095ffea70f0eb432283104
    ReservedCode2: 30440220065c50451b5b81bd108028dec22ace732338c1b42b9b6254fb4043586315fe7102200c4cf8f5a45e44e373dce67f8caa41caef684202db0a9010cefd42697b8f8bd9
---

# 翰林阁 - 网文小说论坛

一个使用 Flask 构建的网文小说论坛系统，支持用户注册登录、发帖评论、管理员后台等功能。

## 功能特性

### 用户功能
- 用户注册与登录
- 个人用户主页（显示用户信息、发帖记录、评论记录）
- 浏览帖子列表
- 查看帖子详情
- 发布新帖子
- 评论帖子
- 修改个人资料

### 管理员功能
- 管理员登录
- 管理仪表盘
- 管理所有用户（查看、禁用、删除）
- 管理所有帖子（删除）
- 管理所有评论（删除）
- 系统统计（用户数、帖子数、评论数）

### 公开功能
- 首页展示（最新帖子、热门帖子）
- 帖子分类浏览
- 帖子搜索

## 技术栈

- **后端**: Python 3 + Flask 3.0
- **前端**: HTML5 + CSS3 + Vanilla JavaScript
- **数据库**: SQLite (本地) / PostgreSQL (云端)
- **认证**: Flask-Login
- **生产服务器**: Gunicorn

## 本地运行

### 1. 克隆项目

```bash
git clone <your-repo-url>
cd novel_forum
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

### 3. 初始化数据库

```bash
python init_db.py
```

### 4. 运行应用

```bash
python app.py
```

访问 http://127.0.0.1:5000

## 测试账户

| 角色 | 用户名 | 密码 |
|------|--------|------|
| 管理员 | admin | admin123 |
| 普通用户 | 翰林客 | reader123 |

## 云端部署

### 方案一：Railway（推荐，免费）

1. 访问 [Railway](https://railway.app) 并登录
2. 点击 "New Project" → "Deploy from GitHub"
3. 连接你的 GitHub 仓库
4. Railway 会自动检测并部署

Railway 会自动提供 PostgreSQL 数据库，只需在环境变量中设置：
- `SECRET_KEY`：随机密钥

### 方案二：Render

1. 访问 [Render](https://render.com) 并登录
2. 点击 "New" → "Web Service"
3. 连接 GitHub 仓库
4. 设置构建命令：`pip install -r requirements.txt`
5. 设置启动命令：`gunicorn app:app`
6. 添加环境变量：
   - `SECRET_KEY`：随机密钥
   - `DATABASE_URL`：创建 PostgreSQL 数据库并填入

### 方案三：Heroku

1. 安装 [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)
2. 登录 Heroku：`heroku login`
3. 创建应用：`heroku create your-app-name`
4. 添加 PostgreSQL：`heroku addons:create hobby-dev`
5. 推送代码：`git push heroku main`

### 方案四：VPS（阿里云/腾讯云等）

1. 安装 Python 3.9+ 和 PostgreSQL
2. 配置 Nginx + Gunicorn
3. 使用 systemd 管理服务

## 环境变量说明

| 变量名 | 说明 | 必填 |
|--------|------|------|
| SECRET_KEY | Flask密钥，用于会话加密 | 是 |
| DATABASE_URL | PostgreSQL连接字符串 | 云端部署时必填 |
| POSTS_PER_PAGE | 每页帖子数（默认15） | 否 |
| COMMENTS_PER_PAGE | 每页评论数（默认10） | 否 |

## 项目结构

```
novel_forum/
├── app.py              # Flask主应用
├── models.py           # 数据库模型
├── init_db.py          # 数据库初始化
├── requirements.txt    # Python依赖
├── Procfile            # Heroku部署配置
├── .env.example        # 环境变量示例
├── templates/          # HTML模板
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── post_detail.html
│   ├── user_profile.html
│   ├── admin_*.html
│   └── ...
└── static/             # 静态文件
    ├── css/
    └── js/
```

## 设计风格

- 主题：古典网文风格，融合现代简约
- 主色调：墨色、金色、宣纸白
- 布局：响应式设计，支持桌面和移动端

## License

MIT License
