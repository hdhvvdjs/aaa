---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304402203c97f4a508016f8c1983e2753537ae288674023e7f31e284c6af0c2915df82a70220616f70ccb546da90b6e92f2290a38be76a1bb6af55bb0bcf0685ef824ce3cb47
    ReservedCode2: 3045022100a9ede27afc9414d0c82869c4227c15d59c23c85e665b062b7e4eba553c60682302204dfda67fedff0925c0483ecb090a77062feb231cee17a090ecdbb7bc5ce54d40
---

# 网文小说论坛 - 项目规范

## 1. 项目概述

**项目名称**: 墨香阁 - 网文小说论坛
**项目类型**: 社区论坛Web应用
**核心功能**: 用户可以浏览、发布、评论网文小说相关的帖子和讨论
**目标用户**: 网文小说爱好者、作者、读者

## 2. 技术栈

- **后端**: Python 3 + Flask
- **前端**: HTML5 + CSS3 + Vanilla JavaScript
- **数据库**: SQLite (SQLAlchemy ORM)
- **认证**: Flask-Login
- **前端构建**: 无需构建，原生HTML/CSS/JS

## 3. 功能列表

### 3.1 用户功能
- 用户注册与登录
- 个人用户主页（显示用户信息、发帖记录、评论记录）
- 浏览帖子列表
- 查看帖子详情
- 发布新帖子
- 评论帖子
- 修改个人资料

### 3.2 管理员功能
- 管理员登录
- 管理仪表盘
- 管理所有用户（查看、禁用、删除）
- 管理所有帖子（审核、删除）
- 管理所有评论
- 系统统计（用户数、帖子数、评论数）

### 3.3 公开功能
- 首页展示（最新帖子、热门帖子）
- 帖子分类浏览
- 帖子搜索

## 4. 数据模型

### 4.1 用户 (User)
- id: 主键
- username: 用户名（唯一）
- email: 邮箱（唯一）
- password_hash: 密码哈希
- avatar: 头像URL
- bio: 个人简介
- is_admin: 是否管理员
- is_active: 是否激活
- created_at: 注册时间

### 4.2 帖子 (Post)
- id: 主键
- title: 标题
- content: 内容
- category: 分类
- author_id: 作者ID（外键）
- view_count: 浏览次数
- created_at: 发布时间
- updated_at: 更新时间

### 4.3 评论 (Comment)
- id: 主键
- content: 内容
- post_id: 帖子ID（外键）
- author_id: 评论者ID（外键）
- created_at: 评论时间

### 4.4 分类 (Category)
- id: 主键
- name: 分类名称
- description: 分类描述

## 5. 页面结构

### 5.1 首页 (/)
- 导航栏
- 轮播图/公告区
- 分类导航
- 最新帖子列表
- 热门帖子列表
- 底部信息

### 5.2 用户页面 (/user/<username>)
- 用户头像和信息
- 用户发帖列表
- 用户评论列表
- 个人资料编辑（仅本人可编辑）

### 5.3 管理员页面 (/admin)
- 仪表盘概览
- 用户管理
- 帖子管理
- 评论管理
- 分类管理

### 5.4 帖子详情 (/post/<id>)
- 帖子内容
- 评论列表
- 评论表单

### 5.5 发帖页面 (/post/create)
- 分类选择
- 标题输入
- 内容编辑

## 6. 界面设计

### 6.1 视觉风格
- 主题：古典网文风格，融合现代简约
- 主色调：墨色 (#2c3e50)、金色 (#d4af37)、宣纸白 (#faf8f5)
- 字体：思源宋体（标题）、思源黑体（正文）

### 6.2 布局
- 响应式设计，支持桌面和移动端
- 最大宽度：1200px
- 卡片式布局展示帖子

## 7. 安全考虑

- 密码使用werkzeug.security加密
- 表单CSRF保护
- 输入内容转义防XSS
- SQL注入防护（ORM）
- 会话管理

## 8. 文件结构

```
novel_forum/
├── app.py              # Flask主应用
├── models.py           # 数据库模型
├── init_db.py          # 数据库初始化
├── static/
│   ├── css/
│   │   └── style.css   # 全局样式
│   └── js/
│       └── main.js     # 前端交互逻辑
├── templates/
│   ├── base.html       # 基础模板
│   ├── index.html      # 首页
│   ├── login.html      # 登录页
│   ├── register.html   # 注册页
│   ├── user_profile.html    # 用户主页
│   ├── admin_dashboard.html # 管理员仪表盘
│   ├── post_detail.html     # 帖子详情
│   ├── create_post.html     # 发布帖子
│   └── edit_profile.html    # 编辑资料
├── requirements.txt
└── README.md
```
