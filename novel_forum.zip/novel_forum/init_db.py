"""
翰林阁 - 数据库初始化脚本
支持云端部署的数据库初始化
"""

from app import app, db
from models import User, Category, Post, Comment, init_default_data

def init_database():
    """初始化数据库和默认数据"""
    with app.app_context():
        # 创建所有表
        db.create_all()
        print("数据库表创建成功！")

        # 初始化默认分类
        init_default_data()
        print("默认分类数据初始化完成！")

        # 创建管理员账户
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@hanlin.com',
                is_admin=True,
                bio='翰林阁论坛管理员'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("管理员账户创建成功！")
            print("用户名: admin")
            print("密码: admin123")
        else:
            print("管理员账户已存在！")

        # 创建测试用户
        test_user = User.query.filter_by(username='翰林客').first()
        if not test_user:
            test_user = User(
                username='翰林客',
                email='reader@hanlin.com',
                bio='热爱网文的普通读者一枚'
            )
            test_user.set_password('reader123')
            db.session.add(test_user)
            db.session.commit()
            print("测试用户创建成功！")
            print("用户名: 翰林客")
            print("密码: reader123")

        # 创建示例帖子
        if Post.query.count() == 0:
            author = User.query.filter_by(username='翰林客').first()
            category = Category.query.filter_by(name='玄幻奇幻').first()

            if author and category:
                sample_posts = [
                    {
                        'title': '《凡人修仙传》能否成为修仙小说的巅峰之作？',
                        'content': '''说起修仙小说，《凡人修仙传》绝对是绕不开的经典。韩立的修仙之路，没有逆天背景，没有贵人相助，全凭自己的努力和机缘。

这本书最吸引人的地方在于：
1. 修炼体系严谨详尽
2. 主角性格低调内敛
3. 配角形象鲜明生动
4. 剧情跌宕起伏

大家觉得，还有哪些修仙小说可以与之比肩呢？''',
                        'category_id': category.id
                    },
                    {
                        'title': '最近追的书单推荐，书荒的看过来！',
                        'content': '''作为一个老书虫，给大家推荐几本最近在追的好书：

【玄幻类】
- 《星门》：老鹰的新书，质量有保障
- 《长夜余火》：爱潜水的乌贼出品

【都市类】
- 《夜的命名术》：会说话的肘子新作
- 《我的治愈系游戏》：解压好书

【科幻类】
- 《深海余烬》：蒸汽朋克风格，很有新意

以上都是本人亲测好看的，保证不书荒！''',
                        'category_id': category.id
                    },
                    {
                        'title': '讨论：网文套路化严重，如何突破？',
                        'content': '''现在的网文市场，套路化越来越严重。开局废柴、退婚、戒指老爷爷...这些套路看多了真的会审美疲劳。

我个人觉得要突破套路化，可以从以下几个方面入手：

1. 人物塑造：让配角有自己的故事线
2. 世界观创新：构建独特的世界规则
3. 剧情反转：出人意料又在情理之中
4. 文笔提升：好的文笔能让老套路焕发新生

大家有什么看法？欢迎留言讨论！''',
                        'category_id': category.id
                    }
                ]

                for post_data in sample_posts:
                    post = Post(author_id=author.id, **post_data)
                    db.session.add(post)

                db.session.commit()
                print(f"示例帖子创建成功！共{len(sample_posts)}篇")

if __name__ == '__main__':
    init_database()
