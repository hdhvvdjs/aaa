#!/bin/bash
# 墨香阁 - 启动脚本

cd /workspace/novel_forum

# 初始化数据库（如需要）
python init_db.py

# 启动Flask应用
echo "正在启动墨香阁论坛..."
python app.py
